import pandas as pd
import numpy as np
import networkx as nx
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D


##################################################################################
#################################### Partie 1 ####################################
##################################################################################

# Charger les fichier 
def read_data (csvfile) :
    data=pd.read_csv(csvfile)
    cord_pt = data[['x', 'y', 'z']].values
    n = len(data)
    return cord_pt, n

# Matrice des distances 
def matrice_distances (cord_pt, n) : 
    distances = np.zeros((n, n))
    for i in range(n):
        for j in range(i + 1, n):
            dx = cord_pt[i, 0] - cord_pt[j, 0]
            dy = cord_pt[i, 1] - cord_pt[j, 1]
            dz = cord_pt[i, 2] - cord_pt[j, 2]
            d = np.sqrt(dx**2 + dy**2 + dz**2)
            distances[i, j] = d
            distances[j, i] = d
    return distances

# Matrice d'adjacence 
def matrice_adjacence(distances, portee):
    return (distances <= portee).astype(int)

# Fonction pour afficher le graphe en 3D
def plot_3d_graph(distance, portee, title):
    adjacence = matrice_adjacence (distance, portee)
    G = nx.from_numpy_array(adjacence)
    pos = nx.get_node_attributes(G, 'pos')  # Position des noeuds
    if not pos:
        pos = nx.spring_layout(G, dim=3)  # Si aucune position n'est définie, utilise un layout 3D

    fig = plt.figure(figsize=(10, 10))
    ax = fig.add_subplot(111, projection='3d')

    # Ajouter les arêtes
    for edge in G.edges():
        x = [pos[edge[0]][0], pos[edge[1]][0]]
        y = [pos[edge[0]][1], pos[edge[1]][1]]
        z = [pos[edge[0]][2], pos[edge[1]][2]]
        ax.plot(x, y, z, color='b', alpha=0.5)

    # Ajouter les noeuds
    for node in G.nodes():
        ax.scatter(pos[node][0], pos[node][1], pos[node][2], s=100, c='r', marker='o')

    ax.set_title(title)
    plt.show()

# Fonction pour afficher les graphes 3D
def plot_3d_graphs (csvfiles, portees) :
    for i in range(len(csvfiles)):
            cord_pt,n=read_data(csvfiles[i])
            distance=matrice_distances(cord_pt,n)
            for j in range(len(portees)):
                adjacence=matrice_adjacence(distance,portees[j])
                plot_3d_graph (distance, portees[j], 'Graphe '+csvfiles[i]+' portee='+str(portees[j]))

##################################################################################
# Initialistation
csvfiles = ['topology_low.csv','topology_avg.csv','topology_high.csv']
portees = [20000,40000,60000]

##################################################################################
# Affichage des graphes 
#plot_3d_graphs(csvfiles,portees)
plt.show()

##################################################################################
#################################### Partie 2 ####################################
##################################################################################

# Degré par sommet et degré moyen
def degre (adjacence,n):
    degres=[]
    G = nx.from_numpy_array(adjacence)
    degre_deux_a_deux = nx.degree(G)
    for i in range (0,n):
        degres.append(degre_deux_a_deux(i,1))
    degre_moyen = np.mean(degres)
    return degres, degre_moyen

# Clustering 
def clustering (adjacence):
    G = nx.from_numpy_array(adjacence)
    clustering_deux_a_deux = nx.clustering(G)
    clusterings = []
    clusterings = list(clustering_deux_a_deux.values()) 
    clustering_moyen = nx.average_clustering(G)
    return clusterings, clustering_moyen

# Cliques 
def clique (adjacence):
    G = nx.from_numpy_array(adjacence)
    cliques = list(nx.find_cliques(G))
    ordre_clique = [] 
    for clique in cliques:
        ordre_clique.append(len(clique))
    return cliques, ordre_clique

# Composantes connexes
def composantes_connexes (adjacence):
    G = nx.from_numpy_array(adjacence)
    comp_connexes = list(nx.connected_components(G))
    ordre_comp_connexes = []
    for comp_connexe in comp_connexes:
        ordre_comp_connexes.append(len(comp_connexe)) 
    return comp_connexes, ordre_comp_connexes

# Plus courts chemins 
def plus_courts_chemins (adjacence):
    G = nx.from_numpy_array(adjacence)
    plus_courts = list(nx.shortest_path_length(G))
    moyenne_plus_courts = []
    for chemin in plus_courts :
        val = list(chemin[1].values())
        moyenne = np.mean(val) 
        moyenne_plus_courts.append(moyenne)
    return moyenne_plus_courts

# Nombre plus courts chemins
def nb_plus_courts_chemins (adjacence,n): 
    G = nx.from_numpy_array(adjacence)
    plus_courts = list(nx.shortest_path_length(G))
    nb_plus_courts = []
    for i in range(0, n):
        nb_plus_courts.append([])
        for j in range(0, n):
            if(i != j):
                try:
                    plus_courts = list(nx.all_shortest_paths(G, i, j))
                    nb_plus_courts[i].append([j,len(plus_courts)])
        
                except nx.NetworkXNoPath:    
                    nb_plus_courts[i].append([j,0]) 
    return nb_plus_courts

# Distribution 
def distribution (liste_valeurs):
    distribution  = []
    for i in range(0, max(liste_valeurs) + 1):
        distribution .append(liste_valeurs.count(i))
    return distribution 

# Affichage de histogramme
def affichage_histogramme(donnees,axe_x,axe_y,titre):
    plt.title(titre)
    plt.xlabel(axe_x)
    plt.ylabel(axe_y)
    plt.bar(range(len(donnees)),donnees)

# Affichage des neuf histogrames 
def affichage_neuf_histogrammes(csvfiles, portees,f) :
    plt.figure(figsize=(18, 18))
    for i in range(len(csvfiles)):
            cord_pt,n=read_data(csvfiles[i])
            distance=matrice_distances(cord_pt,n)
            for j in range(len(portees)):
                adjacence=matrice_adjacence(distance,portees[j])
                if f =='degre':
                    donnees,moyenne = degre(adjacence,n)
                    print("Moyenne des degrés des sommets : "+csvfiles[i]+' portee='+str(portees[j]), moyenne)
                    plt.subplot(3,3,(3*i+j+1))
                    affichage_histogramme(donnees,'Satellite','Degré','Degrés '+csvfiles[i]+' portee='+str(portees[j]))
                elif f =='clustering':
                    donnees,moyenne = clustering(adjacence)
                    print("Moyenne des degrés clustring des sommets : "+csvfiles[i]+' portee='+str(portees[j]), moyenne)
                    plt.subplot(3,3,(3*i+j+1))
                    affichage_histogramme(donnees,'Satellite','Degré','Degrés clustering '+csvfiles[i]+' portee='+str(portees[j]))
                elif f=='clique':
                    cliques,ordre_cliques = clique (adjacence)
                    print("Nombre des cliques : "+csvfiles[i]+' portee='+str(portees[j]), len(cliques))
                    plt.subplot(3,3,(3*i+j+1))
                    affichage_histogramme(ordre_cliques,'Clique','Ordre','Cliques '+csvfiles[i]+' portee='+str(portees[j]))
                elif f=='composante' : 
                    comp_connexes,ordre_compconnexes = composantes_connexes (adjacence)
                    print("Nombre des composantes connexes : "+csvfiles[i]+' portee='+str(portees[j]), len(comp_connexes))
                    plt.subplot(3,3,(3*i+j+1))
                    affichage_histogramme(ordre_compconnexes,'Composante connexe','Ordre','Composantes connexes '+csvfiles[i]+' portee='+str(portees[j]))
                elif f=='moyenne_chemin':
                    moyenne_plus_courts = plus_courts_chemins (adjacence)
                    plt.subplot(3,3,(3*i+j+1))
                    affichage_histogramme(moyenne_plus_courts,'Satellite','Distance moyenne','Plus courts chemins '+csvfiles[i]+' portee='+str(portees[j]))


# Affichage de tous les histogrammes 
def affichage_tous_histogrammes (csvfiles,portees,liste_f):
    for f in liste_f:
        affichage_neuf_histogrammes (csvfiles,portees,f)

##################################################################################
# Initialistation
liste_f=['degre','clustering','clique','composante','moyenne_chemin']

##################################################################################
# Affichage des résultats un par un 
#affichage_neuf_histogrammes (csvfiles,portees,'clustering')

##################################################################################
# Affichage de tous les résultats
affichage_tous_histogrammes (csvfiles,portees,liste_f)

##################################################################################
#################################### Partie 3 ####################################
##################################################################################


# Plus courts chemins pour graphe pondéré 
def plus_courts_chemins_values (adjacence):
    G = nx.from_numpy_array(adjacence)
    plus_courts = list(nx.shortest_path_length(G,weight='weight'))
    moyenne_plus_courts = []
    for chemin in plus_courts :
        val = list(chemin[1].values())
        moyenne = np.mean(val) 
        moyenne_plus_courts.append(moyenne)
    return  moyenne_plus_courts

# Affichage des plus courts chemins pour graphe pondéré pour une portee=60Km
def affichage_histogrammes_values(csvfiles) :
    plt.figure(figsize=(18, 6))
    for i in range(len(csvfiles)):
        cord_pt,n=read_data(csvfiles[i])
        distance=matrice_distances(cord_pt,n)
        adjacence=matrice_adjacence(distance,60000)
        moyenne_plus_courts = plus_courts_chemins_values (adjacence)
        plt.subplot(1,3,i+1)
        affichage_histogramme(moyenne_plus_courts,'Satellite','Distance moyenne','Plus courts chemins '+csvfiles[i]+' portee=60Km')

##################################################################################
# Affichage des résultats 
affichage_histogrammes_values(csvfiles)
plt.tight_layout()  
plt.show()